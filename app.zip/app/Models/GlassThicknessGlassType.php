<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class GlassThicknessGlassType extends Model
{
    protected $table = 'glass_thickness_glass_type';
}

