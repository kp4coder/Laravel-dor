<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class HandleHardwareFinish extends Model
{
    protected $table = 'handle_hardware_finish';
}
