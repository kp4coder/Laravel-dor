<footer class="app-footer">
    <div class="site-footer-right">
        © 2024 All Rights Reserved.
        
    </div>
</footer>
<?php /**PATH D:\xampp\htdocs\dor\app\vendor\tcg\voyager\src/../resources/views/partials/app-footer.blade.php ENDPATH**/ ?>