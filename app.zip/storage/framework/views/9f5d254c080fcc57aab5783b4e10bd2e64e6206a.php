


<?php $__env->startSection('content'); ?>
<section>
	<div class="container">
		<!-- MultiStep Form -->
		<div id="msform">
			<h1><?php echo e($page->title); ?></h1>
			<hr/>
			<h2><?php echo $page->excerpt; ?></h2>

			<div class="page-desc" >
				<img src="<?php echo e(Voyager::image($page->image)); ?>"  />
				<?php echo $page->body; ?>

			</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\dor\app\resources\views/front/page.blade.php ENDPATH**/ ?>